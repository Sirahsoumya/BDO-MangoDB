package ma.emsi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionPublicationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionPublicationsApplication.class, args);
	}

}

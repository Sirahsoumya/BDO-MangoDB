package ma.emsi.entity;

public enum Grade {
	Docteur,
	Doctorant,
    PA,
    PH,
    PES

}

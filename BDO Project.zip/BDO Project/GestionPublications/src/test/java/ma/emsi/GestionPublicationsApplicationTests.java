package ma.emsi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionPublicationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
